#!/usr/bin/env python
#coding:utf-8

import json,urllib2

zabbix_url="http://ip/zabbix/api_jsonrpc.php" # api_jsonrpc.php zabbix官方提供的API接口
zabbix_header={"Content-Type":"application/json"} # 指定网页的内容类型为json
zabbix_user="username"
zabbix_pass="password"

#登录认证信息
def login():
    auth_data=json.dumps(
            {
                "jsonrpc":"2.0",
                "method":"user.login",
                "params":{
                    "user":zabbix_user,
                    "password":zabbix_pass
                },
                "id":0, #request id ,任意指定
            }
    )
    request=urllib2.Request(zabbix_url,auth_data)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    result.close()

    if 'result' in response:  #成功返回才有result属性
        auth_code=response['result'] #获取认证token
        print
        print "Login successfully!"
    else:
        print response['error']['data']
    return auth_code

def get_host(auth_code):
    host_list=[]
    get_host_data=json.dumps(
            {
                "jsonrpc":"2.0",
                "method":"host.get",
                "params":{
                    "output":"extend",
                },
                "auth":auth_code,
                "id":1,
            }
    )
    #获取主机列表
    request=urllib2.Request(zabbix_url,get_host_data)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    result.close()
    print "%-15s%-60s%20s%20s%20s%20s%20s" % ('id','name','status','available','snmp_available','jmx_available','ipmi_available')
    for r in response['result']:
        host_list.append(r['hostid'])
    #    print r['hostid'],r['host'],r['name'],r['status'],r['available'],r['snmp_available'],r['jmx_available'],r['ipmi_available']
        print "%-15s%-60s%20s%20s%20s%20s%20s" % (r['hostid'],r['name'],r['status'],r['available'],r['snmp_available'],r['jmx_available'],r['ipmi_available'])
    #    print r
    print
    print "Num of hosts:",len(host_list)
    return 0

#查询group信息
def get_group(auth_code):
    get_group_data=json.dumps({
        "jsonrpc":"2.0",
        "method":"hostgroup.get",
        "params":{
            "output":"extend"
        },
        "auth":auth_code,
        "id":2
    }
    )

    request=urllib2.Request(zabbix_url,get_group_data)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    result.close()

    if 'result' in response:
        print "%-10s%10s" % ('groupid','name')
        for i in response['result']:
            print "%-10s%10s" % (i['groupid'],i['name'])
    else:
        print response['error']['data']
    return 0

#获取模板信息
def get_temp(auth_code):
    get_temp_data=json.dumps(
            {
                "jsonrpc":"2.0",
                "method":"template.get",
                "params":{
                    "output":"extend"
                },
                "auth":auth_code,
                "id":3
            }
    )

    request=urllib2.Request(zabbix_url,get_temp_data)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    result.close()

    temp={}
    if 'result' in response:
        for i in response['result']:
    #        print i['host'],i['templateid']
            temp[i['host']]=i['templateid']
        print "%-50s%10s" % ('host','templateid')
        for i,j in temp.items():
            print "%-50s%10s" % (i,j)
    else:
        print response['error']['data']
    return 0

#添加主机
def add_host(auth_code,host,name,ip,groupid,type):
    for i,j in enumerate(groupid):
        groupid[i]={"groupid":j}
    if type == 'l' or type == 'L':
        temp=[10001,10113]
    elif type == 'w' or type == 'W':
        temp=[10081]
    for i,j in enumerate(temp):
        temp[i]={"templateid":j}
    create_host=json.dumps(
        {
        "jsonrpc":"2.0",
        "method":"host.create",
        "params":{
            "host":host,
            "name":name,
            "interfaces":[
                {
                    "type":1,
                    "main":1,
                    "useip":1,
                    "ip":ip,
                    "dns":"",
                    "port":"10050"
                }
            ],
            "status":0, #创建时停用监控，0代表启用监控
            "groups":groupid,
            "templates":temp,
            "inventory_mode":1
        },
        "auth":auth_code,
        "id":4
        }
    )

    request=urllib2.Request(zabbix_url,create_host)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    result.close()

    if 'result' in response:
        print
        print "Add host successfully!"
    else:
        print "failed"
        print response['error']

def add_liunx(auth_code):
    f=open('linux.cfg')
    for i in f.readlines():
        li=i.strip().split(',')
        host=li[0]
        name=li[1]
        ip=li[2]
        groupid=[2]
        add_host(auth_code,host,name,ip,groupid,'l')

def add_win(auth_code):
    f=open('windows.cfg')
    for i in f.readlines():
        li=i.strip().split(',')
        host=li[0]
        name=li[1]
        ip=li[2]
        groupid=[14]
        add_host(auth_code,host,name,ip,groupid,'w')

def del_host(auth_code):
    hostid=raw_input("Enter the host id(以,号分隔):")
    id_list=hostid.split(',')
    del_host_data=json.dumps(
            {
                "jsonrpc":"2.0",
                "method":"host.delete",
                "params":id_list,
                "auth":auth_code,
                "id":5
            }
    )
    request=urllib2.Request(zabbix_url,del_host_data)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    if 'result' in response:
        print
        print "host"+" "+hostid+" "+"already deleted !!"

def mod_host(auth_code):
    hostid=raw_input("Enter the host id:")
    get_host_data=json.dumps(
            {
                "jsonrpc":"2.0",
                "method":"host.get",
                "params":{
                    "output":"extend",
                    "filter":{
                        "hostid":hostid
                    }
                },
                "auth":auth_code,
                "id":6
            }
    )
    request=urllib2.Request(zabbix_url,get_host_data)
    for key in zabbix_header:
        request.add_header(key,zabbix_header[key])
    result=urllib2.urlopen(request)
    response=json.loads(result.read())
    if 'result' in response:
        print
        for i in response['result']:
            print i['hostid'],i['name'],i['status']
            status=i['status']
    print
    choice=raw_input("Enable（0）or disbale (1) :")
    if status == choice:
        print
        print "The status is same as ur choice !!"
    else:
        mod_host_data=json.dumps(
                {
                "jsonrpc": "2.0",
                "method": "host.update",
                "params": {
                    "hostid": hostid,
                    "status": choice,
                },
                "auth": auth_code,
                "id": 7
                }
        )
        request=urllib2.Request(zabbix_url,mod_host_data)
        for key in zabbix_header:
            request.add_header(key,zabbix_header[key])
        result=urllib2.urlopen(request)
        response=json.loads(result.read())
        if 'result' in response:
            print
            print "Modify successfully !!"
            request=urllib2.Request(zabbix_url,get_host_data)
            for key in zabbix_header:
                request.add_header(key,zabbix_header[key])
            result=urllib2.urlopen(request)
            response=json.loads(result.read())
            if 'result' in response:
                print
                for i in response['result']:
                    print i['hostid'],i['name'],i['status']

while True:
    print '''
            Zabbix admin
    1.login
    2.host list
    3.host group
    4.template
    5.add linux host
    6.add windows host
    7.delete host
    8.modify host
    0.exit
    '''
    choice=raw_input("Pls enter ur choice:")
    if choice == '1':
        auth_code=login()
    elif choice == '2':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        print '''Note:
                    status:     0---enabled  1---disabled
                    available:  0---gray 1---green 2---red'''
        print
        get_host(auth_code)
    elif choice == '3':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        get_group(auth_code)
    elif choice == '4':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        get_temp(auth_code)
    elif choice == '5':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        add_liunx(auth_code)
    elif choice == '6':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        add_win(auth_code)
    elif choice == '7':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        del_host(auth_code)
    elif choice == '8':
        try:
            auth_code
        except NameError:
            print
            print "Pls login first !!"
            continue
        mod_host(auth_code)
    elif choice == '0':
        exit(0)
    else:
        pass
